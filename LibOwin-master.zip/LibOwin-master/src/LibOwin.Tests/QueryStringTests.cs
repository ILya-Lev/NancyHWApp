﻿// Copyright (c) Microsoft Open Technologies, Inc. All rights reserved. See License.txt in the project root for license information.

namespace LibOwin.Owin
{
    using System;
    using Shouldly;
    using Xunit;
    using Xunit.Extensions;

    public class QueryStringTests
    {
        [Theory]
        [InlineData("one=two")]
        [InlineData("one=two&three&four=five")]
        [InlineData("/unusual?but#tolerable")]
        [InlineData("/")]
        [InlineData("")]
        [InlineData(null)]
        public void ConstructorAndValuePropertyArePassThrough(string value)
        {
            var queryString = new QueryString(value);
            queryString.Value.ShouldBe(value);
        }

        [Theory]
        [InlineData("one=two", "?one=two")]
        [InlineData("one=two&three&four=five", "?one=two&three&four=five")]
        [InlineData("/unusual?but#tolerable", "?/unusual?but%23tolerable")]
        [InlineData("/", "?/")]
        [InlineData("", "")]
        [InlineData(null, "")]
        public void ToUriComponentWillPrependQueryDelimiterAndEscapeFragmentDelimeter(string value, string uriComponent)
        {
            var queryString = new QueryString(value);
            queryString.ToUriComponent().ShouldBe(uriComponent);
            queryString.ToString().ShouldBe(uriComponent);
        }

        [Theory]
        [InlineData("?one=two", "one=two")]
        [InlineData("???one=two", "??one=two")]
        [InlineData("?one=two&thr$ee&four=five", "one=two&thr$ee&four=five")]
        [InlineData("?one=two&thr%24ee&four=five", "one=two&thr%24ee&four=five")]
        [InlineData("?/unusual?but#tolerable", "/unusual?but#tolerable")]
        [InlineData("?/unusual?but%23tolerable", "/unusual?but%23tolerable")]
        [InlineData("?", "")]
        [InlineData("???", "??")]
        [InlineData("", "")]
        [InlineData(null, "")]
        public void FromUriComponentWillRemoveQueryDelimiterAsAppropriate(string uriComponent, string value)
        {
            var queryString = QueryString.FromUriComponent(uriComponent);
            queryString.Value.ShouldBe(value);
        }

        [Theory]
        [InlineData("http://example.com/?one=two%2B", "one=two%2B")]
        [InlineData("http://example.com/???one=two", "??one=two")]
        [InlineData("http://example.com/?one=two&thr$ee&four=five", "one=two&thr$ee&four=five")]
        [InlineData("http://example.com/?one=two&thr%24ee&four=five", "one=two&thr%24ee&four=five")]
        [InlineData("http://example.com/?/unusual?but#tolerable", "/unusual?but")]
        [InlineData("http://example.com/?/unusual?but%23tolerable", "/unusual?but%23tolerable")]
        [InlineData("http://example.com/?", "")]
        [InlineData("http://example.com/???", "??")]
        [InlineData("http://example.com/", "")]
        [InlineData("http://example.com", "")]
        public void FromUriObjectTakesQueryStringValueAsAppropriate(string uriComponent, string value)
        {
            var queryString = QueryString.FromUriComponent(new Uri(uriComponent));
            queryString.Value.ShouldBe(value);
        }

        [Fact]
        public void LeadingDelimiterIsNotOptionalWhenDataPresent()
        {
            Should.Throw<ArgumentException>(() => QueryString.FromUriComponent("one=two"));
        }
    }
}
